﻿Console.WriteLine("LAB15_EBEAM_1200922");
Console.ForegroundColor = ConsoleColor.Red;
Console.WriteLine("Generador de numeros entre -100 hasta 100");
Console.ForegroundColor = ConsoleColor.White;
int[,] Matrix = new int[40, 50];
Random random = new Random();

//generar numeros
for (int i = 0; i < 40; i++)
{
    for (int j = 0; j < 50; j++)
    {
        Matrix[i, j] = random.Next(-100, 100);
    }
}

//print matrix
for (int i = 0; i < 40; i++)
{
    for (int j = 0; j < 50; j++)
    {
        Console.Write(Matrix[i, j] + " | ");
    }
}
Console.WriteLine("Presione cualquier tecla para continuar....");
Console.ReadKey();


int suma = 0;
for (int i = 0; i < 40; i++)
{
    for (int j = 0; j < 50; j++)
    {
        suma = suma + Matrix[i, j];
    }
}
Console.ForegroundColor = ConsoleColor.Red;
Console.WriteLine("La suma de los numeros positivos y negativos es: " + suma);
Console.ForegroundColor = ConsoleColor.White;
Console.WriteLine("Presione cualquier tecla para continuar....");
Console.ReadKey();


